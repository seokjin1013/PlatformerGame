#pragma once

#include "Vec2.hpp"

const Vec2<int> MAX_RESOLUTION = {640, 360};
const Vec2<int> MAX_RESOLUTION_BOARDER = { 30, 30 };
const double epsilon = 0.001;