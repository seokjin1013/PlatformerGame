#pragma once

#include "Vec2.hpp"

const Vec2<int> MAX_RESOLUTION = {640, 360};